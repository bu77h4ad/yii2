<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;

class BookSearch extends Book
{
    public function getAuthor()
    {
        return $this->hasOne(Author::class,['ID'=>'Author_ID']);
    }
    public function attributes()
    {
        // делаем поле зависимости доступным для поиска
        return array_merge(parent::attributes(), ['author.Author']);
    }

    public function rules()
    {
        // только поля определенные в rules() будут доступны для поиска
        return [
            //[['ID'], 'integer'],
            [['Name','author.Author'], 'safe'],
        ];
    }

    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    public function search($params)
    {
        $query = Book::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        // загружаем данные формы поиска и производим валидацию
        if (!($this->load($params) && $this->validate())) {
            return $dataProvider;
        }

        // изменяем запрос добавляя в его фильтрацию
        $query->andFilterWhere(['ID' => $this->ID]);
        $query->andFilterWhere(['like', 'Name', $this->Name]);
        $query->andFilterWhere(['Like', 'Author', $this->getAttribute('author.Author')]);
        $query->joinWith(['author' => function($query) { $query->from(['Author' => 'Author_ID']); }]);
        //    ->andFilterWhere(['like', 'date_create', $this->date_create]);
        // добавляем сортировку по колонке из зависимости

        $dataProvider->sort->attributes['author.Author'] = [
            'asc' => ['author.Author' => SORT_ASC],
            'desc' => ['author.Author' => SORT_DESC],
        ];

        return $dataProvider;
    }
}