<?php
echo "HOME";