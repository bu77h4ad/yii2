<?php

use yii\data\ActiveDataProvider;
use yii\grid\GridView;

//echo "222222222222";



$customer = \app\models\Book::find()
->where(['like','Name','чет'])
->all();
//$string = serialize($customer);
//var_dump($string[0]);
//echo "\n---\n";
//var_dump( $customer[0]->Name );
//echo $customer[0]->Name;

//echo  $book[0]->Name;
echo GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => [
        //'ID',
        'Name',
        'Author_ID',
        'PublishingHouse',
        'AgeLimit',
        'date_create',
        'author.Author',
        [
            'attribute' => 'date_create',
            'format' => ['date', 'php:d.m.Y']
        ],
        ['class' => 'yii\grid\ActionColumn'],
        ],

]);

?>




<?php/*
<table border="1">
   <caption>Книги</caption>
   <tr>
    <th>Название</th>
    <th>Автор</th>
    <th>Запись создана</th>

   </tr>
   <?php foreach ($book as $currentBook): ?>
   <tr><td><?= $currentBook->Name ?></td>
       <td><?= $currentBook->author->Author ?></td>
       <td><?= yii::$app->formatter->asDate($currentBook->date_create,'php:d.m.Y') ?></td>

   <?php endforeach;?>
   </tr>

  </table>
*/
?>